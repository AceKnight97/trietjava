export interface User {
    username: string;
    email: string;
    numberPhone: string;
}