import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewUserComponent } from './new-user/new-user.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { UserListComponent } from './user-list/user-list.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [
  {
    path:'users',
    component: UsersComponent,
    children: [
      {
        path:'',
        component: UserListComponent,
        children: [
          {
            path:'', component: UserInfoComponent
          },
        ]
      },
      {
        path:'new-user', component: NewUserComponent
      },
      {
        path:'edit-user/:userName', component: NewUserComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }
