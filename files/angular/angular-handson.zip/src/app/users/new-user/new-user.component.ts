import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss']
})
export class NewUserComponent implements OnInit {
  userName = '';
  registerForm: FormGroup;

  constructor(private route: ActivatedRoute, 
    private loginService: LoginService, private router: Router,
    private _snackBar: MatSnackBar) {
    this.registerForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required]),
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      age: new FormControl(''),
      salary: new FormControl('')
    });
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      console.log("Params: ", params);
      this.userName = params['userName'] || '';
    });

    console.log('Khoa Check: ', this.registerForm);
  }

  register() {
    this.loginService.register(this.registerForm.value).subscribe(() => {
      const snackBarRef = this._snackBar.open('Register successfully!', 'Dismiss', {
        duration: 3000
      });

      snackBarRef.afterDismissed().subscribe(() => {
        if(localStorage.getItem('auth_token')) {
          this.router.navigate(['/users']);
        }else {
          this.router.navigate(['/login']);
        }
      });
    });

  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000
    });
  }

  get f() {
    return this.registerForm.controls;
  }
}
