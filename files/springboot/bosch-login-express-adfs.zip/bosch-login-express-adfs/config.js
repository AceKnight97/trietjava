exports.creds = {
  identityMetadata: 'https://stfs.bosch.com/adfs/.well-known/openid-configuration', 
  clientID: '099955b2-2ee7-45fa-a7b2-5811d53be35c',
  clientSecret: 'zhODF_w2IKCyKtFKjLzb3MeZcySSuZ5zz69FUjau', 
  responseType: 'code', 
  responseMode: 'query', 
  redirectUrl: 'http://localhost:3000/login/oauth2/code/oidc', 
  allowHttpForRedirectUrl: true,
  validateIssuer: true,
  issuer: 'https://stfs.bosch.com/adfs',
  passReqToCallback: false,
  useCookieInsteadOfSession: false,
  scope: ['openid'],
  loggingLevel: 'info',
  nonceLifetime: null,
  nonceMaxAmount: 5,
  clockSkew: null,
  isB2C: false
};


exports.destroySessionUrl = 'https://login.microsoftonline.com/common/oauth2/logout?post_logout_redirect_uri=http://localhost:3000';
exports.useMongoDBSessionStore = false;
// exports.databaseUri = 'mongodb://localhost/OIDCStrategy';
// exports.mongoDBSessionMaxAge = 24 * 60 * 60;