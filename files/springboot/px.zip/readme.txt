run install.bat for service installation
run uninstall.bat for service uninstallation

----For more information----
https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Weec97bc756ba_4649_add2_019ef95bc91f/page/Installing%20python%20packages%20via%20pip%20and%20conda%20-%20proxy%20issues
https://github.com/genotrance/px