﻿using Canteen.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Canteen.Services
{
    public class FoodService
    {
        private static FoodService _instance = new FoodService();

        public static FoodService Instance
        {
            get { return _instance; }
        }

        internal List<Food> addFood(List<Food> food)
        {
            List<Food> res = new List<Food>();
            res.AddRange((IEnumerable<Food>)food);

            return res;
        }
    }
}