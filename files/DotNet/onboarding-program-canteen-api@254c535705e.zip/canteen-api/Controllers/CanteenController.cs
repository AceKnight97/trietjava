﻿using System.Collections.Generic;
using System.Web.Http;
using System.Web.Mvc;
using Canteen.Models;
using Canteen.Services;

namespace Canteen.Controllers
{
    public class CanteenController : ApiController
    {
        private readonly FoodService foodService;

        public CanteenController()
        {
            this.foodService = new FoodService();
        }

        [System.Web.Http.HttpPost]
        public MutationResponse addFood(AddFood addFood)
        {
            List<Food> food = addFood.food;
            List<Food> saveFood = foodService.addFood(food);

            MutationResponse res = new MutationResponse();
            res.isSucess = !(food == null);
            res.data = saveFood;

            return res;
        }
    }
}