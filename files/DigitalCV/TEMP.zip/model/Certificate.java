package Group4.DigitalCV.model;

import lombok.Data;

import java.time.LocalDate;

import javax.persistence.*;
import javax.persistence.Id;


@Entity
@Table(name = "certificates")
@Data
public class Certificate {
	@Id
	Long id;
    LocalDate date;
    String certificateName;
    String organizationName;

}
