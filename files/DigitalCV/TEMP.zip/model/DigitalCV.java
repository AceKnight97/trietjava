package Group4.DigitalCV.model;

import lombok.Data;

import javax.persistence.*;
import javax.persistence.Id;
import java.util.List;
import java.util.Set;


@Entity
@Table(name = "digitalcvs")
@Data
public class DigitalCV {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
    
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "up_id")
    PersionalInfo persionalInfo;

    // List<Education> educations;
    // List<Certificate> certificates;
    // String hobby;
    // List<Reference> references;
    // List<ProgrammingLanguage> programmings;
    // String otherSkills[];
    // List<WorkExperience> workExperiences;
    // List<Project> projects;

    @Column(name = "photo")
    String photo;

    @Column(name = "jobTitle")
    String jobTitle;

    @Column(name = "photo")
    String cvType;

}
