package Group4.DigitalCV.model;

import lombok.Data;

import java.time.LocalDate;

import javax.persistence.*;
import javax.persistence.Id;

enum Gender {
    Male,
    Female,
    Others
}

@Entity
@Table(name = "personal_info")
@Data
public class PersionalInfo {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

    @Column(name = "email")
    String email;

    @Column(name = "phone")
    String phone;

    @Column(name = "address")
    String address;

    @Column(name = "gender")
    Enum<Gender> gender;

    @Column(name = "dob")
    LocalDate dob;

    @Column(name = "linkedin")
    String linkedin;

    @Column(name = "careerObjective")
    String careerObjective;

    @Column(name = "username")
    String username;
    
}
