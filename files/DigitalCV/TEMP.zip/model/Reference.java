package Group4.DigitalCV.model;

import lombok.Data;

import javax.persistence.*;
import javax.persistence.Id;


@Entity
@Table(name = "references")
@Data
public class Reference {
	@Id
	Long id;
    String name;
    String email;
    String phone;

}
