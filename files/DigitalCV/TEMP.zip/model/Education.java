package Group4.DigitalCV.model;

import lombok.Data;

import java.time.LocalDate;

import javax.persistence.*;
import javax.persistence.Id;


@Entity
@Table(name = "educations")
@Data
public class Education {
	@Id
	Long id;
	String name;
	String major;
	LocalDate from;
	LocalDate to;
}
