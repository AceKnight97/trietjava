package Group4.DigitalCV.model;

import lombok.Data;

import java.time.LocalDate;

import javax.persistence.*;
import javax.persistence.Id;


@Entity
@Table(name = "work_experiences")
@Data
public class WorkExperience {

	@Id
	Long id;
    LocalDate from;
    LocalDate to;
    String companyName;
    String jobTitle;
    String jobDescription;

}
