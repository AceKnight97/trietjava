package Group4.DigitalCV.model;

import lombok.Data;

import javax.persistence.*;
import javax.persistence.Id;


@Entity
@Table(name = "projects")
@Data
public class Project {
	@Id
	Long id;
    String name;
    String languages;
    String description;
}
