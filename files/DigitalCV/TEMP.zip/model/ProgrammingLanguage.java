package Group4.DigitalCV.model;

import lombok.Data;

import javax.persistence.*;
import javax.persistence.Id;

enum Level {
    Novice,
    Amateur,
    Learner,
    Skilled,
    Expert
}

@Entity
@Table(name = "programming_languages")
@Data
public class ProgrammingLanguage {
	@Id
	Long id;
    String technicalSkillset;
    String competence;
    Enum<Level> level;
}
