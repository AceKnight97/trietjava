/**
 * Data Transfer Objects.
 */
package com.mycompany.myapp.service.dto;
