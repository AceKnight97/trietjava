package com.adfs.oidc.demo.configs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@Configuration
@EnableWebSecurity
public class SecurityConfigs extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors();
        http.authorizeRequests(auth -> {
            try {
                auth.antMatchers("/login/**").permitAll()
                        .anyRequest().authenticated()
                        .and()
                        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).oauth2Login(oauth2Login ->
                oauth2Login.loginPage("/oauth2/authorization/oidc")
                        .successHandler(new CustomSuccessHandler())
                        .authorizationEndpoint(authorizationEndpointConfig ->
                        authorizationEndpointConfig.authorizationRequestRepository(new InMemoryRequestRepository())));
    }

    public class CustomSuccessHandler implements AuthenticationSuccessHandler {
        private ObjectMapper objectMapper = new ObjectMapper();

        @Override
        public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException {
            OAuth2User extractPrincipal = (OAuth2User) authentication.getPrincipal();
            Map<String, Object> info = extractPrincipal.getAttributes();

            objectMapper.registerModule(new JavaTimeModule());
            httpServletResponse.getWriter().write(objectMapper.writeValueAsString(info));
        }
    }
}

