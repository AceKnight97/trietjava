import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  baserURL = 'http://localhost:8080/'
  apiUrls = {
    user: this.baserURL + 'login/oauth2/code/oidc',
    home: this.baserURL + 'hello'
  }

  constructor(private http: HttpClient) { }

  get<T>(url: string): Observable<T> {
    return this.http.get<T>(url);
  }
}
