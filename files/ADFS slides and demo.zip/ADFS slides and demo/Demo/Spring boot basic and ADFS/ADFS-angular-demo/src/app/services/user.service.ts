import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private apiService: ApiService) { }

  getUserLoginInfo(state: string, code: string): Observable<any> {
    return this.apiService.get<String[]>(`${this.apiService.apiUrls.user}?code=${code}&state=${state}`);
  }

}
