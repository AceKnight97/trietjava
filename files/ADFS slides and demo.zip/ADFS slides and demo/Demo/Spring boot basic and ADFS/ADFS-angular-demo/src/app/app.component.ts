import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ADFS-Angular';
  defaultStatus = "Login with ADFS"
  username: string = "";
  message: string = "";
  status: string = this.defaultStatus;

  constructor(private userService: UserService, private router: ActivatedRoute) {
    this.router.queryParams.subscribe((item) => {
      if (item?.state) {
        this.login(item.code, item.state);
      }
      else
        this.message = "Please Login";
    });
  }

  login(state: string, code: string) {
   this.userService.getUserLoginInfo(code, state).subscribe(
      (res) => {
       this.username = res.firstname;
       this.message = "Wellcome "
       this.status = "Logout"
      },
      (error) => {
        console.log('ERROR:', error);
        this.username = "";
        this.status = this.defaultStatus;
      }
    );
  }
}
