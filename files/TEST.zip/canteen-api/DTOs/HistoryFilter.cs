﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace canteen_api.Models
{
    public class HistoryFilter
    {
        public string Email { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}