﻿using canteen_api.DTOs;
using canteen_api.Models.DBContext;
using System;

namespace canteen_api.Models
{
    public class OrderHistory
    {
        public FoodDTO Food { get; set; }
        public FoodOrderDTO FoodOrder { get; set; }
        public UserDTO User { get; set; }
    }
}