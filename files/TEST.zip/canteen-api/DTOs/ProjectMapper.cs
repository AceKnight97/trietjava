﻿using AutoMapper;
using canteen_api.Models.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace canteen_api.DTOs
{
    public class ProjectMapper : Profile
    {
        public ProjectMapper()
        {
            CreateMap<User, UserDTO>();
            CreateMap<Food, FoodDTO>();
            CreateMap<FoodOrder, FoodOrderDTO>();
            //.ForMember(dest => dest.Name, s => s.MapFrom(source => source.DepartmentName))
            //.ForMember(dest => dest.Groups, s => s.Ignore());
            //CreateMap<DeptGroup, GroupDto>()
            //.ForMember(dest => dest.Name, s => s.MapFrom(source => source.GroupName));
            //CreateMap<LibraryDto, InsertLibraryModel>()
            //.ForMember(dest => dest.IsActiveThisYear, s => s.MapFrom(source => source.Status == "Active"));
            //CreateMap<InsertLibraryModel, Library>()
            //.ForMember(dest => dest.LibrarySpecialRoleLevels, s => s.MapFrom(source => source.LevelIds.SelectMany(x => source.SpecialRoleIds.Select(y => new LibrarySpecialRoleLevel()
            //{
            //    LevelId = x,
            //    SpecialRoleId = y,
            //})).ToList()))
            //.ForMember(rt => rt.RoleTitles, s => s.MapFrom(source => string.Join(",", source.RoleIds)))
            //.ForMember(dest => dest.LearningAPId, s => s.MapFrom(source => source.LearningApproachId));
            //CreateMap<AssessmentDetail, Assessment>();
            //CreateMap<Category, CategoryModel>();
            //CreateMap<Competence, CompetenceModel>();
            //CreateMap<Competency, CompetencyModel>();
            //CreateMap<LearningSession, Session>();



            //CreateMap<LearningClass, ClassInformationUpdate>()
            //.ForMember(dest => dest.LearningClassId, opt => opt.MapFrom(src => src.Id))
            //.ForMember(dest => dest.TargetLearnerIds, opt => opt.MapFrom(src => src.TargetLearners.Select(t => t.RoleTitleId)));
            //CreateMap<LearningSession, SessionUpdate>()
            //.ForMember(dest => dest.LearningSessionId, opt => opt.MapFrom(src => src.Id));
            //CreateMap<LearningClass, LearningLibraryUpdateModel>()
            //.ForMember(dest => dest.ClassInformationUpdate, opt => opt.MapFrom(src => src))
            //.ForMember(dest => dest.SessionUpdates, opt => opt.MapFrom(src => src.LearningSessions));
            //CreateMap<ClassInformation, LearningClass>()
            //.ForMember(dest => dest.TargetLearners, s => s.MapFrom(source => source.TargetLearnerIds.Select(x => new TargetLearner
            //{
            //    RoleTitleId = x,
            //    IsActive = true
            //}).ToList()));
            ////CreateMap<BudgetPlanUpdateItem, AllowedBudgetDetail>();
        }
    }
}