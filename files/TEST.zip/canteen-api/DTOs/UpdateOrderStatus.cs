﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace canteen_api.Models
{
    public class UpdateOrderStatus
    {
        public int Food_ID { get; set; }
        public string Status { get; set; }
    }
}