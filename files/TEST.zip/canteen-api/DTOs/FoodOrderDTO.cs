﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace canteen_api.DTOs
{
    public class FoodOrderDTO
    {
        public int ID { get; set; }
        public Nullable<double> Quantity { get; set; }
        public int Food_ID { get; set; }
        public Nullable<System.DateTime> CreatedAt { get; set; }
        public string Email { get; set; }
        public string Status { get; set; }
        public string Notes { get; set; }
        public Nullable<double> Price { get; set; }
    }
}