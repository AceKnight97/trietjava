﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using canteen_api.Services.FoodOrderService;
using System.Collections.Generic;
using System.Web.Http;
using HttpGetAttribute = System.Web.Http.HttpGetAttribute;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;
using RouteAttribute = System.Web.Http.RouteAttribute;
using RoutePrefixAttribute = System.Web.Http.RoutePrefixAttribute;

namespace canteen_api.Controllers
{
    [RoutePrefix("api/FoodOrder")]
    public class FoodOrderController : ApiController
    {
        private readonly DBContext db;
        private readonly IFoodOrderService foodOrderService;

        public FoodOrderController(IFoodOrderService _foodOrderService)
        {
            this.db = new DBContext();
            this.foodOrderService = _foodOrderService;
        }

        [HttpPost]
        [Route("AdminHistory")]
        public List<OrderHistory> GetAllHistory(HistoryFilter historyFilter)
        {
            return foodOrderService.GetAllHistory(historyFilter);
        }

        [HttpPost]
        [Route("CreateOrder")]
        public MutationResponse CreateOrder(List<FoodOrder> receiveOrders)
        {
            List<FoodOrder> savedOrders = foodOrderService.CreateOrder(receiveOrders);

            MutationResponse res = new MutationResponse();
            res.IsSuccess = !(savedOrders == null);
            res.Data = savedOrders;

            return res;
        }

        [HttpPost]
        [Route("ChangeOrderStatus")]
        public MutationResponse ChangeOrderStatus(UpdateOrderStatus data)
        {
            MutationResponse res = new MutationResponse();
            FoodOrder foodOrder = foodOrderService.ChangeOrderStatus(data);
            res.IsSuccess = !(foodOrder == null);
            res.Data = foodOrder;
            return res;
        }
    }
}