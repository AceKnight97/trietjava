﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;
using RouteAttribute = System.Web.Http.RouteAttribute;
using RoutePrefixAttribute = System.Web.Http.RoutePrefixAttribute;

namespace canteen_api.Controllers
{
    [RoutePrefix("api/public")]
    public class AuthApiController :ApiController
    {
        private readonly DBContext db;
        public AuthApiController(DBContext db)
        {
            this.db = db;
        }

        [HttpPost]
        [Route("login")]
        public MutationResponse Login(AuthRequest request)
        {
            MutationResponse res = new MutationResponse();
            AuthResponse auth = new AuthResponse();
            string email = request.Email;
            string password = request.Password;

            User user = db.Users.FirstOrDefault(x => x.Email == email && x.Password == password);

            if (user == null)
            {
                res.IsSuccess = false;
                return res;
            }

            if (email == user.Email && password == user.Password)
            {
                string token = "123";
                auth.User = user;
                auth.Token = token;
                res.Data = auth;
                res.IsSuccess = true;
            }
            else
            {
                res.IsSuccess = false;
            }

            return res;
        }
    }
}