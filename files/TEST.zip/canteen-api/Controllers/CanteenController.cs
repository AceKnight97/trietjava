﻿
using canteen_api.Models;
using canteen_api.Models.DBContext;
using canteen_api.Services.FoodService;
using canteen_api.Services.UserService;
using canteen_api.Utils;
using System.Collections.Generic;
using System.Web.Http;
using RouteAttribute = System.Web.Http.RouteAttribute;
using RoutePrefixAttribute = System.Web.Http.RoutePrefixAttribute;

namespace Canteen.Controllers
{
    [RoutePrefix("api/Canteen")]
    public class CanteenController : ApiController
    {
        private readonly IFoodService foodService;
        private readonly IUserService userService;

        public CanteenController(IFoodService foodService, IUserService userService)
        {
            this.foodService = foodService;
            this.userService = userService;
        }

        [HttpPost]
        [Route("AddFood")]
        public MutationResponse AddFood(AddFood addFood)
        {
            List<Food> foods = addFood.food;
            List<Food> saveFood = foodService.AddFood(foods);

            MutationResponse res = new MutationResponse();
            res.IsSuccess = !(saveFood == null);
            res.Data = saveFood;

            return res;
        }

        [HttpGet]
        [Route("Menu")]
        public List<Food> GetMenu()
        {
            UserUtil userUtil = new UserUtil();
            userUtil.GetNtUserEmail();
            return this.foodService.GetMenu();
        }

        [HttpPut]
        [Route("UpdateFood")]
        public MutationResponse UpdateFood(AddFood addFood)
        {
            List<Food> foods = addFood.food;
            List<Food> updatedFoods = foodService.UpdateFood(foods);

            MutationResponse res = new MutationResponse();
            res.IsSuccess = !(updatedFoods == null);
            res.Data = updatedFoods;

            return res;
        }


        [HttpDelete]
        [Route("DeleteFood")]
        public MutationResponse DeleteFood(AddFood addFood)
        {
            List<Food> foods = addFood.food;
            List<Food> deletedFoods = foodService.DeleteFood(foods);

            MutationResponse res = new MutationResponse();
            res.IsSuccess = !(deletedFoods == null);
            res.Data = deletedFoods;

            return res;
        }
    }
}