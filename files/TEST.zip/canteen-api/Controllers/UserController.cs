﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using canteen_api.Services.UserService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using HttpGetAttribute = System.Web.Http.HttpGetAttribute;
using RouteAttribute = System.Web.Http.RouteAttribute;
using RoutePrefixAttribute = System.Web.Http.RoutePrefixAttribute;

namespace canteen_api.Controllers
{
    [RoutePrefix("api/User")]
    public class UserController : ApiController
    {
        private readonly DBContext db;
        private readonly IUserService userService;
        public UserController(DBContext db, IUserService userService)
        {
            this.db = db;
            this.userService = userService;
        }

        [HttpGet]
        [Route("{id}")]
        public User getUser(int ID)
        {
            return userService.GetUser(ID);
        }

        [Route("CreateUser")]
        public MutationResponse createUser(CreateUserRequest data)
        {
            MutationResponse response = new MutationResponse();

            User user = userService.CreateUser(data);
            if (user == null)
            {
                response.IsSuccess = false;
                response.Message = "User already existed!";
                return response;
            }
            response.Data = user;
            return response;
        }
    }
}