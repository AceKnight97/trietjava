﻿using canteen_api.Models.DBContext;
using canteen_api.Services.FoodOrderService;
using canteen_api.Services.FoodService;
using canteen_api.Services.UserService;
using Microsoft.Extensions.DependencyInjection;
using System.Data.Entity;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Mvc;


namespace canteen_api
{
    public class Bootstrapper
    {
        public static void InitiateServiceProvider()
        {
            IServiceCollection services = new ServiceCollection();
            RegisterServices(services);
            ServiceProviderResolver resolver = new ServiceProviderResolver(services.BuildServiceProvider(), DependencyResolver.Current);
            DependencyResolver.SetResolver(resolver);
            GlobalConfiguration.Configuration.DependencyResolver = resolver;
        }

        private static void RegisterServices(IServiceCollection services)
        {
            // add controller
            var controllerTypes = typeof(Bootstrapper).Assembly
                                                      .GetTypes()
                                                      .Where(type => !type.IsAbstract &&
                                                                    !type.IsGenericTypeDefinition &&
                                                                    (typeof(ControllerBase).IsAssignableFrom(type) ||
                                                                    typeof(IHttpController).IsAssignableFrom(type)));
            foreach (var controllerType in controllerTypes)
            {
                services.AddTransient(controllerType);
            }

            // add other services
            services.AddSingleton<IFoodService, FoodService>();
            services.AddSingleton<IFoodOrderService, FoodOrderService>();
            services.AddSingleton<IUserService, UserService>();
            services.AddSingleton<DBContext>();
        }
    }
}