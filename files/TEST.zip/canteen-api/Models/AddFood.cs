﻿using canteen_api.Models.DBContext;
using System.Collections.Generic;

namespace canteen_api.Models
{
    public class AddFood
    {
        public string Email { get; set; }
        public List<Food> food { get; set; }

        public AddFood()
        {
            food = new List<Food>();
        }
    }
}