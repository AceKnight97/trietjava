﻿using canteen_api.Models.DBContext;
using System;

namespace canteen_api.Models
{
    public class OrderHistory
    {
        public Food Food { get; set; }
        public FoodOrder FoodOrder { get; set; }
        public User User { get; set; }
    }
}