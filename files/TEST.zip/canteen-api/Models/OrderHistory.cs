﻿using System;

namespace canteen_api.Models
{
    public class OrderHistory
    {
        public int Food_ID { get; set; }
        public double Quantity { get; set; }
        public DateTime CreatedAt { get; set; }
        public string Email { get; set; }
        public string Title { get; set; }
        public string Name { get; set; }
        public int Rating { get; set; }
        public int Price { get; set; }
        public QuantityType QuantityType { get; set; }
    }
}