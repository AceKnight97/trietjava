﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using System.Collections.Generic;

namespace canteen_api.Services.FoodService
{
    public interface IFoodService
    {
        List<Food> AddFood(List<Food> food);
        List<Food> GetMenu();
        List<Food> UpdateFood(List<Food> foods);
        List<Food> DeleteFood(List<Food> foods);
    }
}
