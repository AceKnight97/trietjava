﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using canteen_api.Services.FoodService;
using System;
using System.Collections.Generic;
using System.Linq;

namespace canteen_api.Services.FoodService
{
    public class FoodService : IFoodService
    {
        private readonly DBContext db;

        public FoodService(DBContext db)
        {
            this.db = db;
        }

        public List<Food> AddFood(List<Food> foods)
        {
            if (foods.Count == 0)
            {
                return null;
            }

            List<Food> res = db.Foods.ToList();
            int nextAvailableID = 0;

            if (res.Count() > 0)
            {
                nextAvailableID = res.Last().ID;
            }

            foreach (Food food in foods)
            {
                if (food.QuantityType == null)
                {
                    food.QuantityType = 0;
                }

                food.ID = ++nextAvailableID;
                food.CreatedAt = DateTime.Now;

                db.Foods.Add(food);
                res.Add(food);
            }

            db.SaveChanges();

            return res;
        }

        public List<Food> GetMenu()
        {
            List<Food> res = db.Foods.ToList();
            return res;
        }

        public List<Food> UpdateFood(List<Food> foods)
        {
            try
            {
                List<Food> updatedFoods = new List<Food>();

                foreach (Food food in foods)
                {
                    Food dbFood = db.Foods.First(x => x.ID == food.ID);
                    dbFood.Title = food.Title;
                    dbFood.Name = food.Name;
                    dbFood.Rating = food.Rating;
                    dbFood.QuantityType = food.QuantityType;
                    dbFood.Price = food.Price;
                    dbFood.Image = food.Image;

                    updatedFoods.Add(dbFood);
                }

                db.SaveChanges();
                
                return updatedFoods;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public List<Food> DeleteFood(List<Food> foods)
        {
            try
            {
                List<Food> deletedFoods = new List<Food>();

                foreach (Food food in foods)
                {
                    Food dbFood = db.Foods.First(x => x.ID == food.ID);
                    db.Foods.Remove(dbFood);
                    deletedFoods.Add(dbFood);
                }

                db.SaveChanges();

                return deletedFoods;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}