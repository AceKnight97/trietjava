﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using System;
using System.Collections.Generic;

namespace canteen_api.Services.FoodOrderService
{
    public interface IFoodOrderService
    {
        List<FoodOrder> CreateOrder(List<FoodOrder> receiveOrders);
        List<OrderHistory> GetAllHistory(HistoryFilter historyFilter);
        FoodOrder ChangeOrderStatus(UpdateOrderStatus data);
    }
}
