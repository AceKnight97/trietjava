﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using System;
using System.Collections.Generic;

namespace canteen_api.Services.FoodOrderService
{
    public interface IFoodOrderService
    {
        List<OrderHistory> GetHistory(User user, DateTime createdAt);
        List<FoodOrder> CreateOrder(List<FoodOrder> receiveOrders);
        List<OrderHistory> GetHistory();
        List<OrderHistory> GetHistory(string email);
        List<OrderHistory> GetAllHistory(HistoryFilter historyFilter);
    }
}
