﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using canteen_api.Services.FoodService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using canteen_api.Services.FoodOrderService;
using canteen_api.Utils;
using System.Data.Entity;

namespace canteen_api.Services.FoodOrderService
{
    public class FoodOrderService : IFoodOrderService
    {
        private readonly DBContext db;
        private readonly UserUtil userUtil = new UserUtil();
        public FoodOrderService(DBContext db)
        {
            this.db = db;
        }

        public List<OrderHistory> GetHistory()
        {
            List<FoodOrder> orders = new List<FoodOrder>();
            string email = userUtil.GetNtUserEmail();
            User user = db.Users.FirstOrDefault(x => x.Email == email);

            orders = db.FoodOrders.Where(x => x.Email == email).ToList();

            List<OrderHistory> orderHistories = new List<OrderHistory>();

            foreach (FoodOrder order in orders)
            {
                OrderHistory orderHistory = new OrderHistory();
                orderHistory.Food = order.Food;
                orderHistory.FoodOrder = order;
                orderHistory.User = user;

                orderHistories.Add(orderHistory);
            }

            return orderHistories;
        }

        public List<OrderHistory> GetHistory(string email)
        {
            List<FoodOrder> orders = new List<FoodOrder>();
            User user = db.Users.FirstOrDefault(x => x.Email == email);

            if (user != null)
            {
                orders = db.FoodOrders.Where(x => x.Email == email).ToList();

                List<OrderHistory> orderHistories = new List<OrderHistory>();

                foreach (FoodOrder order in orders)
                {
                    OrderHistory orderHistory = new OrderHistory();
                    orderHistory.Food = order.Food;
                    orderHistory.FoodOrder = order;
                    orderHistory.User = user;

                    orderHistories.Add(orderHistory);
                }

                return orderHistories;
            }

            return new List<OrderHistory>();
        }

        public List<OrderHistory> GetHistory(User user, DateTime createdAt)
        {
            List<FoodOrder> orders = new List<FoodOrder>();

            if (createdAt.Year < 10)
            {
                orders = db.FoodOrders.Where(x => x.Email == user.Email).ToList();
            }
            else
            {
                var tmpOrders = db.FoodOrders.Where(x => x.Email == user.Email).ToList();

                foreach (FoodOrder foodOrder in tmpOrders)
                {
                    if (createdAt.ToShortDateString() == foodOrder.CreatedAt.Value.ToShortDateString())
                    {
                        orders.Add(foodOrder);
                    }
                }
            }

            List<OrderHistory> orderHistories = new List<OrderHistory>();

            foreach(FoodOrder order in orders)
            {
                OrderHistory orderHistory = new OrderHistory();
                orderHistory.Food = order.Food;
                orderHistory.FoodOrder = order;
                orderHistory.User = user;

                orderHistories.Add(orderHistory);
            }

            return orderHistories;
        }

        public List<OrderHistory> GetAllHistory(HistoryFilter historyFilter)
        {
            List<User> users = db.Users.ToList();
            List<OrderHistory> res = new List<OrderHistory>();

            foreach(User user in users)
            {
                List<OrderHistory> orderHistories = GetHistory(user, historyFilter.CreatedAt);
                res.AddRange(orderHistories);
            }

            return res;
        }


        public List<FoodOrder> CreateOrder(List<FoodOrder> receiveOrders)
        {
            try
            {
                int nextAvailableID = 0;

                if (db.FoodOrders.Count() > 0)
                {
                    nextAvailableID = db.FoodOrders.Last().ID;
                }

                foreach (FoodOrder foodOrder in receiveOrders)
                {
                    foodOrder.ID = ++nextAvailableID;
                    foodOrder.CreatedAt = DateTime.Now;

                    db.FoodOrders.Add(foodOrder);
                }

                db.SaveChanges();

                return receiveOrders;
            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}