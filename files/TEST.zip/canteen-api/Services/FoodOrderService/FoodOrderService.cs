﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using canteen_api.Services.FoodService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using canteen_api.Services.FoodOrderService;

namespace canteen_api.Services.FoodOrderService
{
    public class FoodOrderService : IFoodOrderService
    {
        private readonly DBContext db;

        public FoodOrderService(DBContext db)
        {
            this.db = db;
        }

        public List<OrderHistory> GetHistory(string email)
        {
            List<FoodOrder> foodOrders = db.FoodOrders.Where(x => x.Email == email).ToList();
            List<OrderHistory> orderHistories = new List<OrderHistory>();

            foreach (FoodOrder foodOrder in foodOrders)
            {
                Food food = db.Foods.First(x => x.ID == foodOrder.Food_ID);

                OrderHistory orderHistory = new OrderHistory();
                orderHistory.Food_ID = food.ID;
                orderHistory.QuantityType = (QuantityType)food.QuantityType;
                orderHistory.Title = food.Title;
                orderHistory.Name = food.Name;
                orderHistory.Rating = (int)food.Rating;
                orderHistory.Price = (int)food.Price;
                orderHistory.Email = foodOrder.Email;
                orderHistory.CreatedAt = (DateTime)foodOrder.CreatedAt;
                orderHistory.Quantity = (double)foodOrder.Quantity;

                orderHistories.Add(orderHistory);
            }

            return orderHistories;
        }

        public List<FoodOrder> CreateOrder(List<FoodOrder> receiveOrders)
        {
            try
            {
                int nextAvailableID = 0;

                if (db.FoodOrders.Count() > 0)
                {
                    nextAvailableID = db.FoodOrders.Last().ID;
                }

                foreach (FoodOrder foodOrder in receiveOrders)
                {
                    foodOrder.ID = ++nextAvailableID;
                    foodOrder.CreatedAt = DateTime.Now;

                    db.FoodOrders.Add(foodOrder);
                }

                db.SaveChanges();

                return receiveOrders;
            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}