﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using canteen_api.Services.FoodService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using canteen_api.Services.FoodOrderService;
using canteen_api.Utils;
using System.Data.Entity;
using AutoMapper;
using canteen_api.DTOs;

namespace canteen_api.Services.FoodOrderService
{
    public class FoodOrderService : IFoodOrderService
    {
        private readonly DBContext db;
        private readonly UserUtil userUtil = new UserUtil();
        private readonly IMapper mapper;

        public FoodOrderService(DBContext db, IMapper mapper)
        {
            this.db = db;
            this.mapper = mapper;
        }

        public List<OrderHistory> GetHistory(User user, DateTime createdAt)
        {
            List<FoodOrder> orders = new List<FoodOrder>();

            if (createdAt.Year < 10)
            {
                orders = db.FoodOrders.Where(x => x.Email == user.Email).ToList();
            }
            else
            {
                var tmpOrders = db.FoodOrders.Where(x => x.Email == user.Email).ToList();

                foreach (FoodOrder foodOrder in tmpOrders)
                {
                    if (createdAt.ToShortDateString() == foodOrder.CreatedAt.Value.ToShortDateString())
                    {
                        orders.Add(foodOrder);
                    }
                }
            }

            List<OrderHistory> orderHistories = new List<OrderHistory>();

            foreach (FoodOrder order in orders)
            {
                OrderHistory orderHistory = new OrderHistory();
                var tmpFood = db.Foods.First(x => x.ID == order.Food_ID);
                orderHistory.Food = this.mapper.Map<Food, FoodDTO>(tmpFood);
                orderHistory.FoodOrder = this.mapper.Map<FoodOrder, FoodOrderDTO>(order);
                orderHistory.User = this.mapper.Map<User, UserDTO>(user);

                orderHistories.Add(orderHistory);
            }

            return orderHistories;
        }

        public List<OrderHistory> GetAllHistory(HistoryFilter historyFilter)
        {
            if (historyFilter.CreatedAt == null)
            {
                historyFilter.CreatedAt = DateTime.Now;
            }

            List<OrderHistory> res = new List<OrderHistory>();

            if (historyFilter.Email == null || historyFilter.Email == "")
            {
                List<User> users = db.Users.ToList();
                
                foreach(User user in users)
                {
                    List<OrderHistory> orderHistories = GetHistory(user, historyFilter.CreatedAt);
                    res.AddRange(orderHistories);
                }
            }
            else
            {
                User user = db.Users.FirstOrDefault(x => x.Email == historyFilter.Email);

                if (user != null)
                {
                    List<OrderHistory> orderHistories = GetHistory(user, historyFilter.CreatedAt);
                    res.AddRange(orderHistories);
                }
            }

            return res;
        }


        public List<FoodOrder> CreateOrder(List<FoodOrder> receiveOrders)
        {
            try
            {
                int nextAvailableID = 0;
                DateTime createdAt = DateTime.Now;
                List<FoodOrder> foodOrders = db.FoodOrders.ToList();
                if (foodOrders.Count() > 0)
                {
                    nextAvailableID = foodOrders.Last().ID + 1;
                }

                foreach (FoodOrder foodOrder in receiveOrders)
                {
                    foodOrder.ID = nextAvailableID;
                    foodOrder.CreatedAt = createdAt;

                    db.FoodOrders.Add(foodOrder);
                }

                db.SaveChanges();

                return receiveOrders;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public FoodOrder ChangeOrderStatus(UpdateOrderStatus data)
        {
            try
            {
                FoodOrder foodOrder = db.FoodOrders.First(x => x.Food_ID == data.Food_ID);
                foodOrder.Status = data.Status;
                db.SaveChanges();

                return foodOrder;
            }
            catch (Exception e)
            {
                // TODO: handle exception
                return null;
            }
        }
    }
}