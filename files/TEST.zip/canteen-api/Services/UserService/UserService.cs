﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Http;

namespace canteen_api.Services.UserService
{
    public class UserService: IUserService
    {
        
        private readonly DBContext db;
        private const string ADMIN_KEY = "0819541897";
        public UserService(DBContext db)
        {
            this.db = db;
        }

        public User GetUser(int ID)
        {
            return db.Users.FirstOrDefault(x => x.ID == ID);
        }

        public List<User> GetUsers()
        {
            return db.Users.ToList();
        }

        public User CreateUser(CreateUserRequest user)
        {
            User newUser = db.Users.FirstOrDefault(x => x.Email == user.Email);

            if (newUser != null)
            {
                return null;
            }

            int nextAvailableID = 0;
            if(db.Users.Count() > 0)
            {
                var users = db.Users.ToList();
                nextAvailableID = users.Last().ID;
            }

            User existUser = new User();
            existUser.ID = ++nextAvailableID;
            existUser.Username = user.Username;
            existUser.Email = user.Email;
            existUser.Address = user.Address;
            existUser.Phone = user.Phone;
            existUser.Password = user.Password;

            if (existUser.Password == ADMIN_KEY)
            {
                existUser.Role = Role.Admin.ToString();
            }
            else
            {
                existUser.Role = Role.Client.ToString();
            }

            db.Users.Add(existUser);
            db.SaveChanges();

            return existUser;
        }
    }
}