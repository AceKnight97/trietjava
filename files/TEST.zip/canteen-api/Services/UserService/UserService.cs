﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace canteen_api.Services.UserService
{
    public class UserService
    {
        public class UserDto
        {
            public int Id { get; set; }
            public string NTID { get; set; }
            public string DisplayName { get; set; }
            public string Email { get; set; }
            public string GroupName { get; set; }
            public string Department { get; set; }
            public List<string> Roles { get; set; }
            public int? DeptGroupId { get; set; }
        }

        public List<UserDto> GetUsersFromAD(string searchKey, int? pageSize = null, bool isLookup = false, string[] exceptionNtids = null)
        {
            if (isLookup)
            {
                searchKey = Regex.Replace(searchKey, @"[^0-9a-zA-Z]+", "");
            }
            else
            {
                var ldapInjectionKeywork = new string[] { "(", ")", "!", "|", "&", "*", "\n", "/", "\\", ".", ",", "%" };

                foreach (var injectionCharacter in ldapInjectionKeywork)
                {
                    searchKey = searchKey.Replace(injectionCharacter, "");
                }
            }

            var users = new List<UserDto>();

            if (string.IsNullOrEmpty(searchKey))
            {
                return users;
            }

            if (!string.IsNullOrEmpty(searchKey))
            {
                searchKey = searchKey.Trim();
                searchKey = searchKey.Replace("  ", " ");

            }

            using (var domain = new DirectoryEntry("LDAP://rb-bcd-gc-defe-luds-12.rb-dirsvc.bosch-org.com:3268/DC=Bosch,DC=com"))
            {
                var searcher = new DirectorySearcher(domain)
                {
                    SearchScope = SearchScope.Subtree
                };
                searcher.PropertiesToLoad.Add("mail"); //email
                searcher.PropertiesToLoad.Add("DisplayName");
                searcher.PropertiesToLoad.Add("sAMAccountName"); //NTID

                var exceptionNtidsFilter = "";
                if (exceptionNtids != null)
                {
                    exceptionNtidsFilter = GetNotExistInNTIDFilter(exceptionNtids);
                }

                if (!isLookup)
                {
                    searcher.Filter = string.Format("(&(objectCategory=Person)(objectClass=user)(!msExchResourceMetaData=ResourceType:Room){1}(|(sAMAccountName={0})(mail={0}*)(DisplayName={0}*)))", searchKey, exceptionNtidsFilter);
                }
                // Specific for find exactly NTID case 
                else
                {
                    searcher.Filter = string.Format("(&(objectCategory=Person)(objectClass=user)(!msExchResourceMetaData=ResourceType:Room){1}(|(sAMAccountName={0})))", searchKey, exceptionNtidsFilter);
                }

                if (pageSize.HasValue)
                {
                    searcher.SizeLimit = pageSize.Value;
                }

                var result = searcher.FindAll();

                if (result.Count > 0)
                {
                    foreach (SearchResult adUser in result)
                    {
                        var user = new UserDto
                        {
                            NTID = adUser.Properties.Contains("sAMAccountName") ? adUser.Properties["sAMAccountName"][0].ToString() : string.Empty,
                            DisplayName = adUser.Properties.Contains("DisplayName") ? adUser.Properties["DisplayName"][0].ToString() : string.Empty,
                            Email = adUser.Properties.Contains("mail") ? adUser.Properties["mail"][0].ToString() : string.Empty,
                        };
                        users.Add(user);
                    }
                }

            }
            return users.Where(u => !string.IsNullOrEmpty(u.Email) && !string.IsNullOrEmpty(u.NTID)).ToList();
        }

        private string GetNotExistInNTIDFilter(string[] ntIds)
        {
            var filter = "";

            foreach (var ntid in ntIds)
            {
                filter += string.Format("(!(sAMAccountName={0}))", ntid);
            }

            return filter;
        }
    }
}