﻿using canteen_api.Models;
using canteen_api.Models.DBContext;
using System.Collections.Generic;
using static canteen_api.Services.UserService.UserService;

namespace canteen_api.Services.UserService
{
    public interface IUserService
    {
        User GetUser(int iD);
        List<User> GetUsers();
        User CreateUser(CreateUserRequest data);
    }
}
