﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Web.Http.Dependencies;

namespace canteen_api
{
    public class ServiceProviderResolver : System.Web.Mvc.IDependencyResolver,
                                           System.Web.Http.Dependencies.IDependencyResolver
    {
        private readonly IServiceProvider serviceProvider;
        private readonly System.Web.Mvc.IDependencyResolver oldResolver;

        public ServiceProviderResolver(IServiceProvider serviceProvider, System.Web.Mvc.IDependencyResolver oldResolver)
        {
            this.serviceProvider = serviceProvider;
            this.oldResolver = oldResolver;
        }

        public IDependencyScope BeginScope()
        {
            return new ServiceProviderResolver(serviceProvider.CreateAsyncScope().ServiceProvider, oldResolver);
        }

        public void Dispose()
        {
        }

        public object GetService(Type serviceType)
        {
            try { return serviceProvider.GetService(serviceType); }
            catch { return oldResolver.GetService(serviceType); }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            try { return serviceProvider.GetServices(serviceType); }
            catch { return oldResolver.GetServices(serviceType); }
        }
    }
}