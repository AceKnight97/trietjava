﻿using canteen_api.Models;
using canteen_api.Services;
using canteen_api.Services.FoodService;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Mvc;
using RouteAttribute = System.Web.Http.RouteAttribute;
using RoutePrefixAttribute = System.Web.Http.RoutePrefixAttribute;

namespace Canteen.Controllers
{
    [RoutePrefix("canteen")]
    public class CanteenController : ApiController
    {
        private readonly IFoodService foodService;

        public CanteenController(IFoodService foodService)
        {
            this.foodService = foodService;
        }

        [System.Web.Http.HttpPost]
        [Route("addFood")]
        public MutationResponse addFood(AddFood addFood)
        {
            List<Food> food = addFood.food;
            List<Food> saveFood = foodService.addFood(food);

            MutationResponse res = new MutationResponse();
            res.isSucess = !(food == null);
            res.data = saveFood;

            return res;
        }
    }
}