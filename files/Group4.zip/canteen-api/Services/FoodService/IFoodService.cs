﻿using canteen_api.Models;
using System.Collections.Generic;

namespace canteen_api.Services.FoodService
{
    public interface IFoodService
    {
        List<Food> addFood(List<Food> food);
    }
}
