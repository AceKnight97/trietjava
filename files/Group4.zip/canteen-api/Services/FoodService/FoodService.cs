﻿using canteen_api.Models;
using canteen_api.Services.FoodService;
using System.Collections.Generic;

namespace canteen_api.Services.FoodService
{
    public class FoodService : IFoodService
    {
        public List<Food> addFood(List<Food> food)
        {
            List<Food> res = new List<Food>();
            res.AddRange((IEnumerable<Food>)food);

            return res;
        }
    }
}