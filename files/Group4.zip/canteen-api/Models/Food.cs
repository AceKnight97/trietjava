﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace canteen_api.Models
{
    public enum Quantity
    {
        WEIGHT,
        PACKAGE,
    }

    public class Food
    {
        public int id { get; set; }
        public string title { get; set; }
        public string name { get; set; }
        public int rating { get; set; }
        public int price { get; set; }
        public Quantity quantity { get; set; }
        public string image { get; set; }
    }
}