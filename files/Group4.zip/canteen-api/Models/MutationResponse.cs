﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace canteen_api.Models
{
    public class MutationResponse
    {
        public bool isSucess { get; set; }
        public string message { get; set; }
        public object data { get; set; }
    }
}