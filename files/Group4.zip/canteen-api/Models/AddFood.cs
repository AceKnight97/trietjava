﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace canteen_api.Models
{
    public class AddFood
    {
        public string email { get; set; }
        public List<Food> food { get; set; }

        public AddFood()
        {
            food = new List<Food>();
        }
    }
}